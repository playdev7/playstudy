module com.ruby.demo {
	exports com.ruby.demo;
	requires com.ruby.func;
	uses com.ruby.func.MyProvider;
}