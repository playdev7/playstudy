package com.ruby.func;

public interface MyProvider {
	public MySubFunc get();
}
