package com.ruby.func;

public interface MySubFunc {
	public String getName();
	
	public int func(int a, int b);
}
