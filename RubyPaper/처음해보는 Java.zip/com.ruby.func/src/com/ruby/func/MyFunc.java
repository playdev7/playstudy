package com.ruby.func;

import com.ruby.util.MyUtil;

public class MyFunc {
	public static void get() {
		System.out.println("Hello Java!!");
	}

	public void print() {
		MyUtil.add();
	}

}
