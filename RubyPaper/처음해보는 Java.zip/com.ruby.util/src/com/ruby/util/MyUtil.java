package com.ruby.util;

public class MyUtil {
  public static void add() {
    System.out.println("Module System!");
  }
}