package com.ruby.java.ch07.abstraction;

public class test {

}
