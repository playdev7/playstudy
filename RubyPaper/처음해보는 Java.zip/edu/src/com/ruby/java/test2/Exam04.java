package com.ruby.java.test2;

public class Exam04 {

}
