package com.ruby.java.test2.io;

public class Exam05 {

}
