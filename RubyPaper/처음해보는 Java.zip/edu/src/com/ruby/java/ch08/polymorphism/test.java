package com.ruby.java.ch08.polymorphism;

public class test {

}
