package com.ruby.java.ch09;

public class Test13 {
	public static void main(String[] args) {
		boolean bool3 = Boolean.parseBoolean("true");
		byte b3 = Byte.parseByte("12");
		double d3 = Double.parseDouble("3.14");
		float f3 = Float.parseFloat("10.5f");
		int i3 = Integer.parseInt("123");
		long l3 = Long.parseLong("123456789");
		short s3 = Short.parseShort("256");
	}
}