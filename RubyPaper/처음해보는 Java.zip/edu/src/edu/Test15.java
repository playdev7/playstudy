package edu;

public class Test15 {
	public static void main(String[] args) {
		char c = 'F';
		String gender = (c == 'F') ? "����" : "����";
		System.out.println(gender);
	}
}