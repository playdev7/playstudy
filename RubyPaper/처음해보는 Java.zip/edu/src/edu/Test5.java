package edu;

public class Test5 {
	public static void main(String[] args) {
		int A1 = 10;
		int A2 = 20;
		int A3 = A1 + A2;

		System.out.println(A3);
	}
}