package edu;

public class Test35 {
	public static void main(String[] args) {
		int[] arr = { 10, 20, 30, 40, 50 };

		for (int num : arr) {
			System.out.println(num);
		}
	}
}