package edu;

public class Test10 {
	public static void main(String[] args) {
		boolean isOn = true;
		isOn = !isOn;
		System.out.println(isOn);
	}
}