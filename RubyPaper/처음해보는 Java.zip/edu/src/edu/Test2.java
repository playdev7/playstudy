package edu;

public class Test2 {

	public static void main(String[] args) {
		int depositAmount;
		depositAmount = 50000;
		System.out.println(depositAmount);
	}

}