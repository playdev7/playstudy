package edu;

public class Test8 {
	public static void main(String[] args) {
		int a = 10;
		int b = 20;

		System.out.println(a > b); // false
		System.out.println(a < b); // true
		System.out.println(a >= b); // false
		System.out.println(a <= b); // true
		System.out.println(a == b); // false
		System.out.println(a != b); // true
	}
}