package edu;

public class Test4 {
	public static void main(String[] args) {
		float exchangeRate = 1136.50F;
		double USDAmount = 600.50;
		double KRWAmount = 682468.25;

		System.out.println(exchangeRate);
		System.out.println(USDAmount);
		System.out.println(KRWAmount);
	}
}