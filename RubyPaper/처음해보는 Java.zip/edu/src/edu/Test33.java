package edu;

public class Test33 {
	public static void main(String[] args) {
		int[] arr = { 10, 20, 30, 40, 50 };

		System.out.println(arr[0]);
		System.out.println(arr[1]);
		System.out.println(arr[2]);
		System.out.println(arr[3]);
		System.out.println(arr[4]);
	}
}