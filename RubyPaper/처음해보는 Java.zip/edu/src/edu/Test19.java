package edu;

public class Test19 {
	public static void main(String[] args) {
		int score = 90;
		String result = "";

		if (score >= 60) {
			result = "�հ�";
		} else {
			result= "���հ�";
		}
		System.out.println(result);
	}
}